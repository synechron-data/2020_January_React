import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
// import { BrowserRouter } from 'react-router-dom';
import { Router } from 'react-router-dom';
import history from './history';

import 'bootstrap';

import RootComponent from './components/root/RootComponent';

import { Provider } from 'react-redux';
import configureStore from './store/configureStore';

const appStore = configureStore();
// const appStore = configureStore({ counterReducer: 100 });
// console.log(appStore.getState());

// ReactDOM.render(<Provider store={appStore}>
//     <BrowserRouter>
//         <RootComponent />
//     </BrowserRouter>
// </Provider>, document.getElementById('root'));

ReactDOM.render(<Provider store={appStore}>
    <Router history={history}>
        <RootComponent />
    </Router>
</Provider>, document.getElementById('root'));