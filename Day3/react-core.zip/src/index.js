import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';

import RootComponent from './components/root/RootComponent';

ReactDOM.render(<RootComponent />, document.getElementById('root'));