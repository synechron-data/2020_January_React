/* eslint-disable */
import React, { Component } from 'react';
import ErrorHandler from '../common/ErrorHandler';
import Assignment from '../1_Assignment';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    <Assignment />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;