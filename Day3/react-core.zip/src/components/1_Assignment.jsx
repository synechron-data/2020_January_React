import React, { Component } from 'react';
import TextInput from './common/TextInput';
import DataTable from './common/DataTable';

class FormComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { id: 0, name: "", designation: "", salary: "" };
        this.updateState = this.updateState.bind(this);
        this.save = this.save.bind(this);
        this.reset = this.reset.bind(this);
    }

    updateState(e) {
        const field = e.target.id;
        var newState = { ...this.state };
        if ((field == "id") && e.target.value)
            newState[field] = parseInt(e.target.value);
        else
            newState[field] = e.target.value;
        this.setState(newState);
    }

    save(e) {
        e.preventDefault();
        this.props.onSave(this.state);
    }

    reset(e) {
        this.setState({ id: 0, name: "", designation: "", salary: "" });
    }

    render() {
        return (
            <div className="row">
                <div className="col-sm-6 offset-sm-3">
                    <form className="form-horizontal" autoComplete="off" onSubmit={this.save}>
                        <fieldset>
                            <legend className="text-center text-secondary text-uppercase font-weight-bold">Manage Employee Information</legend>
                            <hr className="mt-0" />
                            <TextInput label={"Id"} name={"id"} onChange={this.updateState} value={this.state.id} />
                            <TextInput label={"Name"} name={"name"} onChange={this.updateState} value={this.state.name} />
                            <TextInput label={"Designation"} name={"designation"} onChange={this.updateState} value={this.state.designation} />
                            <TextInput label={"Salary"} name={"salary"} onChange={this.updateState} value={this.state.salary} />

                            <div className="row mt-3">
                                <div className="col">
                                    <button type="submit" className="btn btn-success btn-block">Save</button>
                                </div>
                                <div className="col">
                                    <button type="reset" className="btn btn-primary btn-block" onClick={this.reset}>Reset</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        );
    }
}

class Assignment extends Component {
    constructor(props) {
        super(props);
        this.state = { employees: [] };
        this.addEmployee = this.addEmployee.bind(this);
        this.removeEmployee = this.removeEmployee.bind(this);
    }

    addEmployee(employee) {
        this.setState({ employees: [...this.state.employees, { ...employee }] });
    }

    removeEmployee(id, e) {
        this.setState({
            employees: [...this.state.employees.filter((item) => {
                return item.id != id;
            })]
        });
    }

    render() {
        console.log(this.state.employees);
        return (
            <div>
                <FormComponent onSave={this.addEmployee} />
                <DataTable items={this.state.employees} onDelete={this.removeEmployee}>
                    <h5 className="text-primary text-uppercase font-weight-bold">Employees Table</h5>
                </DataTable>
            </div>
        );
    }
}

export default Assignment;