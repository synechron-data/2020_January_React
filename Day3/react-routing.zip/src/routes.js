import React from 'react';
import { Switch, Route, Redirect } from "react-router-dom";

import authenticator from './services/authenticator.service';

import HomeComponent from "./components/home/HomeComponent";
import AboutComponent from "./components/about/AboutComponent";
import ProductComponent from './components/products/ProductComponent';
import AdminComponent from './components/admin/AdminComponent'
import LoginComponent from './components/login/LoginComponent';

const SecuredRoute = ({ component: Component, ...args }) => {
    return (
        <Route {...args} render={
            (props) => authenticator.isAuthenticated === true ? <Component {...props} /> :
                <Redirect to={{ pathname: '/login', state: { from: props.location } }} />
        } />
    );
};

export default (
    <Switch>
        <Route exact path="/" component={HomeComponent} />
        <Route path="/about" component={AboutComponent} />
        <Route path="/products" component={ProductComponent} />
        <SecuredRoute path="/admin" component={AdminComponent} />
        <Route path="/login" component={LoginComponent} />
        <Route path="**" render={
            () => (
                <article>
                    <h1 className="text-danger">No Route Configured!</h1>
                    <h4 className="text-danger">Please check your Route Configuration</h4>
                </article>
            )
        } />
    </Switch>
);