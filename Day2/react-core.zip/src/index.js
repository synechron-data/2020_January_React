import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';

import RootComponent from './components/Root/RootComponent';

ReactDOM.render(<RootComponent />, document.getElementById('root'));