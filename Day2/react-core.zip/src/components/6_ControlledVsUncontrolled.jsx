import React, { Component } from 'react';

class ControlledVsUncontrolled extends Component {
    constructor(props) {
        super(props);
        this.state = { name: "Synechron" };
        this.handleChange = this.handleChange.bind(this);
        this.handleClick = this.handleClick.bind(this);
    }

    handleChange(e) {
        this.setState({ name: e.target.value });
    }

    handleClick(e) {
        this.setState({ name: this.refs.t1.value });
    }

    render() {
        return (
            <div>
                <div className="text-center">
                    <h3 className="text-info">Controlled & Uncontrolled Component</h3>
                </div>
                {/* <input type="text" />
                <br />
                <input type="text" defaultValue={"Manish"} />
                <br />
                <input type="text" value={"Manish"} /> */}

                {/* <input type="text" />
                <br />
                <input type="text" defaultValue={this.state.name} />
                <br />
                <input type="text" value={this.state.name} /> */}

                {/* <input type="text" value={this.state.name} onChange={this.handleChange} />
                <h2 className="text-info">Name is: {this.state.name}</h2> */}

                <input ref="t1" type="text" defaultValue={this.state.name} />
                <h2 className="text-info">Name is: {this.state.name}</h2>
                <button className="btn btn-primary" onClick={this.handleClick}>Click</button>
            </div>
        );
    }
}

export default ControlledVsUncontrolled;