import React, { Component } from 'react';

class ComponentOne extends Component {
    render() {
        console.log(this.state);
        console.log(this.props);
        return (
            <div>
                <h2 className="text-info">Using Class Syntax</h2>
            </div>
        );
    }
}

// Functional / Stateless / Presentational (Presentation)
const ComponentTwo = () => {
    // console.log(this.state);
    // console.log(this.props);
    return (
        <div>
            <h2 className="text-info">Using Arrow Syntax</h2>
        </div>
    );
};

const ComponentThree = (props) => {
    console.log(props);
    return (
        <div>
            <h2 className="text-info">Using Arrow Syntax</h2>
        </div>
    );
};

const ComponentFour = ({ id, name }) => {
    console.log(id);
    console.log(name);
    return (
        <div>
            <h2 className="text-info">Using Arrow Syntax</h2>
        </div>
    );
};

const ComponentFive = ({ id, name, ...address }) => {
    console.log(id);
    console.log(name);
    console.log(address);
    return (
        <div>
            <h2 className="text-info">Using Arrow Syntax</h2>
        </div>
    );
};

class ClassVsFunctionComponent extends Component {
    render() {

        return (
            <div>
                <ComponentOne />
                <ComponentTwo />
                <ComponentThree id={1} name={"Manish"} state={"MH"} city={"Pune"} />
                <ComponentFour id={1} name={"Manish"} state={"MH"} city={"Pune"} />
                <ComponentFive id={1} name={"Manish"} state={"MH"} city={"Pune"} />
            </div>
        );
    }
}

export default ClassVsFunctionComponent;