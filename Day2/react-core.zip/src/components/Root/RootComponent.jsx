/* eslint-disable */
import React, { Component } from 'react';
import ComponentWithBehavior from '../1_ComponentWithBehavior';
import ClassVsFunctionComponent from '../2_ClassVsFunctionComponent';
import EventComponent from '../3_EventComponent';
import CounterAssignment from '../4_CounterAssignment';
import DataFlowAssignment from '../5_DataFlowAssignment';
import ControlledVsUncontrolled from '../6_ControlledVsUncontrolled';
import CalculatorAssignment from '../7_CalculatorAssignment';
import PropTypesRoot from '../8_PropTypes';
import ErrorHandler from '../common/ErrorHandler';
import ListRoot from '../9_ListComponent';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <ComponentWithBehavior /> */}
                    {/* <ClassVsFunctionComponent /> */}
                    {/* <EventComponent /> */}
                    {/* <CounterAssignment /> */}
                    {/* <DataFlowAssignment /> */}
                    {/* <ControlledVsUncontrolled /> */}
                    {/* <CalculatorAssignment /> */}
                    {/* <PropTypesRoot /> */}
                    <ListRoot />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;