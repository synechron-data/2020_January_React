import React, { Component } from 'react';

class HelloComponent extends Component {
    render() {
        return (
            <h1 className={'text-info'}>Hello World</h1>
        );
    }
}

export default HelloComponent;

// ------------------------------------------------------

// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         // return null;
//         // return "Hello";
//         // return 10;
//         // return true;
//         // return Symbol("Hello");
//         // return {};                               // Not Work
//         // return { id: 1, message: "Hello" };      // Not Work
//         // return [10,20,30];
//         return (
//             [
//                 <h1>Hello World</h1>,
//                 <h1>Hello World Again</h1>
//             ]
//         );
//         // return (
//         //     <div>
//         //         <h1>Hello World</h1>
//         //         <h1>Hello World Again</h1>
//         //     </div>
//         // );
//         // return (
//         //     <React.Fragment>
//         //         <h1>Hello World</h1>
//         //         <h1>Hello World Again</h1>
//         //     </React.Fragment>
//         // );
//     }
// }

// export default HelloComponent;

// // -----------------------------------------

// import React, { Component } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return (
//             <React.Fragment>
//                 <h1>Hello World</h1>
//                 <h1>Hello World Again</h1>
//             </React.Fragment>
//         );
//     }
// }

// export default HelloComponent;

// // ----------------------------------------- Function Syntax

// import React from 'react';

// // function HelloComponent() {
// //     return (
// //         <React.Fragment>
// //             <h1>Hello World - Functional Component</h1>
// //             <h1>Hello World Again</h1>
// //         </React.Fragment>
// //     );
// // }

// const HelloComponent = function () {
//     return (
//         <React.Fragment>
//             <h1>Hello World - Functional Component</h1>
//             <h1>Hello World Again</h1>
//         </React.Fragment>
//     );
// }

// export default HelloComponent;

// ----------------------------------------- Arrow Syntax

// import React from 'react';

// // const HelloComponent = () => {
// //     return (
// //         <React.Fragment>
// //             <h1>Hello World - Arrow Functional Component</h1>
// //             <h1>Hello World Again</h1>
// //         </React.Fragment>
// //     );
// // }

// const HelloComponent = () => (
//     <React.Fragment>
//         <h1>Hello World - Arrow Functional Component</h1>
//         <h1>Hello World Again</h1>
//         <button>Click Me</button>
//     </React.Fragment>
// );

// export default HelloComponent;