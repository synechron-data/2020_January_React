import React, { Component } from 'react';
import './ComponentTwo.css';

class ComponentTwo extends Component {
    render() {
        return (
            <h1 className="card2 text-success">Hello from Component Two</h1>
        );
    }
}

export default ComponentTwo;