import React, { Component } from 'react';

class ComponentWithProps extends Component {
    constructor(props) {
        super(props);
        // this.state = { name: "Synechron" };
        // this.props = { name: "Synechron" };

        // this.props.id = 100;
        // this.state = this.props;

        // Shallow Copy
        // this.state = Object.assign({}, this.props);
        // this.state = {...this.props};

        // Deep Copy
        this.state = JSON.parse(JSON.stringify(this.props));

        // Deep Copy With Functions (Methods) - immutability-helper

        this.state.address.city = "Mumbai";

        console.log("Ctor, State: ", this.state);
        console.log("Ctor, Props: ", this.props);
    }

    render() {
        this.props.display();
        console.log("Render, State: ", this.state);
        console.log("Render, Props: ", this.props);
        return (
            <div>
                {/* <h2 className="text-info">Hello, {++this.props.id}</h2>
                <h2 className="text-info">Hello, {this.props.name}</h2> */}

                <h2 className="text-info">Id, {++this.state.id}</h2>
                <h2 className="text-info">Hello, {this.state.name}</h2>
                <h2 className="text-info">From, {this.state.address.city}</h2>
            </div>
        );
    }
}

export default ComponentWithProps;