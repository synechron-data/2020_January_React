import React, { Component } from 'react';

class ComponentTwo extends Component {
    render() {
        return (
           <h1 className="text-info">Hello from Component Two</h1>
        );
    }
}

export default ComponentTwo;